#ifndef OBSERVER_H
#define OBSERVER_H

#include "main.h"

void* observe(void *firstSlot);

#endif