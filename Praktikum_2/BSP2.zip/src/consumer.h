#ifndef CONSUMER_H
#define CONSUMER_H

#include "main.h"
#include "qeue.h"

void* consMain(void *firstSlot);

#endif 