#ifndef PRODUCER_H
#define PRODUCER_H

#include "main.h"
#include "qeue.h"

void* prodMain(void *firstSlot);

#endif